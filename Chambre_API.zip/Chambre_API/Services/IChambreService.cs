﻿namespace Chambre_API.Services
{
    public class IChambreService
    {
    }
}
