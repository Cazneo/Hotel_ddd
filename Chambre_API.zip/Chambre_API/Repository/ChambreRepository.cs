﻿namespace Chambre_API.Repository
{
    public class ChambreRepository
    {
    }
}
