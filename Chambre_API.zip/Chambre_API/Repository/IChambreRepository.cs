﻿using Chambre_API.Model;

namespace Chambre_API.Repository
{
    public interface IChambreRepository
    {
            void Add(Chambre chambre);
            Chambre GetById(int id);
            void Update(Chambre chambre);
            void Delete(int id);
    }
}

