﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Chambre_API.Model
{
    public class TypeChambre
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int TypeChambreID { get; set; }
        public string? NomType { get; set; }
        public float? PrixParNuit { get; set; }
    }

}
